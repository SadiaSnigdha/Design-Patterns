package visitor;
interface Shape {
    void accept(Visitor visitor);
}
