package labmid.Factory;

import labmid.Prototype.PatientRecord;

public interface DepartmentFactory {
        PatientRecord createRecord();
    }


